# LLD Practice Platform

A small end-to-end practice loop for Low-Level Design: choose a problem, submit a structured
design, get rubric-based feedback (deterministic + AI), retry, and review your attempt history.

See [`docs/research-note.md`](docs/research-note.md) and [`docs/design-note.md`](docs/design-note.md)
for the problem research and the design/evaluation reasoning. See [`AI_USAGE.md`](AI_USAGE.md) for
how AI was used while building this.

## Requirements

- Node.js 18+ (uses the built-in `fetch` and `crypto.randomUUID`)

## Setup

```bash
npm install
```

## Running the app

```bash
npm start
```

Then open **http://localhost:3000**. Data is persisted to `data.json` in the project root (a
plain JSON file — see the design note for why) and seeded with 4 problems on first run.

### Enabling real AI evaluation (optional)

By default there is no `ANTHROPIC_API_KEY`, so the AI-graded criteria run through a deterministic
heuristic mock (keyword/length signals) — the full loop works out of the box with no keys. To get
real LLM-graded feedback instead:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
npm start
```

The server logs which mode it's running in on startup.

## Running tests

```bash
npm test
```

22 tests covering: domain logic (rubric weighting, evaluation status transitions and scoring), the
deterministic structural gate, the evaluation service's orchestration (gate short-circuiting,
evaluator registration/skip-if-unsupported), the AI evaluator's fallback behaviour (no key /
network failure / malformed response), the async queue's status transitions + idempotent retry,
and a full HTTP practice loop test (start attempt → submit → poll → completed feedback → shows in
history), plus a failure-path test (incomplete submission never reaches the AI evaluator).

Tests use an isolated data file and an injected fake AI evaluator — no network calls are made
during `npm test`.

## Project layout

```
src/
  domain/        Problem, Attempt, Submission, Rubric/Criterion, Evaluation/CriterionResult
  services/      DeterministicEvaluator, AiEvaluator, MockAiEvaluator, EvaluationService, EvaluationQueue
  repositories/  JSON-file backed repositories (one per entity)
  routes/        problems, attempts (+ nested submissions), evaluations
  data/          seed problems.json
  app.js         wires everything together (used by both server.js and tests)
  server.js      entry point
public/          vanilla JS/HTML frontend, no build step
tests/           mirrors src/ structure
docs/            research note, design note
```

## Key decisions and limitations

- **Submission format is structured text** (four required sections), not a diagram editor or code
  sandbox — see design note for the reasoning and the trade-off.
- **No authentication** — single fixed "guest" learner for this MVP; `learnerId` is threaded
  through the domain so adding real accounts later doesn't require a schema change.
- **Storage is a single JSON file**, not a database — zero setup, not concurrency-hardened; fine
  for a single-instance prototype, not for production.
- **The evaluation queue is in-process** (`setImmediate` + an in-memory in-flight set), not a real
  message broker — deliberately, per the assignment's scope boundary. It still demonstrates the
  right behaviours: persist-before-evaluate, non-blocking submission, and idempotent retry.
- **The AI evaluator needs `ANTHROPIC_API_KEY` for real grading**; without it, feedback comes from
  a heuristic mock, which is intentionally low-confidence and keyword-based, not a good evaluator
  in its own right — it exists to make the pipeline demonstrable and to be a safe fallback target.
- **One rubric shared across all problems** rather than a rubric per problem.
