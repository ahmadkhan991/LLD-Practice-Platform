# AI Usage

This project was built collaboratively with Claude (Claude Sonnet, via Claude.ai), used as an
active design/implementation partner rather than a one-shot code generator — the brief itself
invites this ("we are evaluating how well you use AI together with your own judgement"). Below are
the meaningful decision points from that process: what Claude suggested, what was kept, changed, or
rejected, and why.

**Before submitting, review the domain model and evaluation design in `docs/design-note.md` and be
ready to defend every decision below in your own words — that's the part of this exercise that's
actually being graded.**

## 1. Submission format: one format, not "support everything"

Claude's first instinct was to support text, code, *and* diagram submissions simultaneously, on the
reasoning that more formats give more evidence of design quality. This was rejected in favor of a
single structured-text format (four required sections: Classes & Responsibilities, Relationships,
Extensibility, Edge Cases & Trade-offs). The candidate helping guide explicitly warns against "a
good decision here is not 'support everything'"; a single well-chosen format that's cheap to build
and easy to evaluate deterministically (are the sections there?) was judged more valuable than
breadth. The `Evaluator` interface still supports adding a second format later without touching the
domain model — see decision 3.

## 2. Frontend: vanilla JS over React

Claude's default suggestion was a React/Vite frontend (consistent with prior projects using that
stack). This was overridden in favor of a plain HTML/CSS/vanilla-JS single page, specifically
because the guide states reviewers would be "less impressed by lots of UI with weak practice
logic." Given the two-day budget, spending zero time on frontend tooling and all of it on the
domain model and evaluation pipeline (25% + 15% of the grade) was judged the better trade — a build
step and component structure wouldn't have improved a reviewer's read of the LLD itself.

## 3. Evaluator architecture: an explicit Strategy interface, not a single "do evaluation" function

Claude's first draft combined structural checks and AI-quality checks inside one evaluation
function. This was reworked into a formal `Evaluator` interface (`supports()` + `evaluate()`) with
`DeterministicEvaluator` and `AiEvaluator` as separate, independently testable implementations
orchestrated by `EvaluationService`. This was a deliberate response to two of the assignment's
explicit design questions — "which parts should be deterministic vs AI" and "how would your design
accommodate another evaluation approach later" — since a single function can describe extensibility
in prose, but only a real interface boundary can be *exercised* by a test (see
`evaluationService.test.js`, which registers a fake evaluator and asserts it's skipped for
unsupported formats).

## 4. Storage: a JSON file, not MongoDB, for the prototype

Claude initially reached for MongoDB by default (matching the stack used on other projects). This
was replaced with a plain JSON-file-backed store for the prototype: no DB connection/auth failure
surface to debug within a two-day window, and it doesn't affect any of the graded dimensions
(LLD, evaluation approach, extensibility). The repository classes (`ProblemRepository`,
`AttemptRepository`, etc.) expose the same `find`/`save` surface a Mongoose-backed version would,
specifically so this remains a contained, later swap rather than a rewrite.

## 5. AI evaluator reliability: a tested fallback path, not a bare API call

Claude's first pass called the Anthropic API directly with no failure handling. This was rejected:
the assignment explicitly asks "what should happen if evaluation takes time or fails," and a bare
API call has no real answer to that. The accepted design wraps the call with a timeout, catches
network/parsing failures, and falls back to a keyword-heuristic mock evaluator implementing the
*same* interface — so a real answer exists (the evaluation still completes, just with lower
`confidence` scores) instead of the pipeline failing outright. This path is covered by tests that
simulate a missing API key and a rejected fetch call, rather than just asserted in prose.
