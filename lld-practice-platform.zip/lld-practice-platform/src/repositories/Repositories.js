const Problem = require('../domain/Problem');
const Attempt = require('../domain/Attempt');
const Submission = require('../domain/Submission');
const { Evaluation } = require('../domain/Evaluation');

class ProblemRepository {
  constructor(store) {
    this.store = store;
  }
  findAll() {
    return this.store.all('problems').map((p) => new Problem(p));
  }
  findById(id) {
    const raw = this.store.find('problems', (p) => p.id === id);
    return raw ? new Problem(raw) : null;
  }
  save(problem) {
    this.store.upsert('problems', problem.toJSON());
    return problem;
  }
}

class AttemptRepository {
  constructor(store) {
    this.store = store;
  }
  save(attempt) {
    this.store.upsert('attempts', attempt.toJSON());
    return attempt;
  }
  findById(id) {
    const raw = this.store.find('attempts', (a) => a.id === id);
    return raw ? new Attempt(raw) : null;
  }
  findByLearner(learnerId) {
    return this.store
      .filter('attempts', (a) => a.learnerId === learnerId)
      .map((a) => new Attempt(a))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
}

class SubmissionRepository {
  constructor(store) {
    this.store = store;
  }
  save(submission) {
    this.store.upsert('submissions', submission.toJSON());
    return submission;
  }
  findById(id) {
    const raw = this.store.find('submissions', (s) => s.id === id);
    return raw ? new Submission(raw) : null;
  }
  findByAttempt(attemptId) {
    return this.store
      .filter('submissions', (s) => s.attemptId === attemptId)
      .map((s) => new Submission(s));
  }
}

class EvaluationRepository {
  constructor(store) {
    this.store = store;
  }
  save(evaluation) {
    this.store.upsert('evaluations', {
      id: evaluation.id,
      submissionId: evaluation.submissionId,
      attemptId: evaluation.attemptId,
      problemId: evaluation.problemId,
      rubricId: evaluation.rubricId,
      status: evaluation.status,
      results: evaluation.results,
      error: evaluation.error,
      createdAt: evaluation.createdAt,
      completedAt: evaluation.completedAt,
    });
    return evaluation;
  }
  findById(id) {
    const raw = this.store.find('evaluations', (e) => e.id === id);
    return raw ? new Evaluation(raw) : null;
  }
  findBySubmission(submissionId) {
    const raw = this.store.find('evaluations', (e) => e.submissionId === submissionId);
    return raw ? new Evaluation(raw) : null;
  }
}

module.exports = { ProblemRepository, AttemptRepository, SubmissionRepository, EvaluationRepository };
