const fs = require('fs');
const path = require('path');

/**
 * A tiny synchronous, file-backed key-value collection store.
 *
 * Why not MongoDB/SQLite for the prototype: the assignment explicitly
 * rewards judgement over impressiveness, and a real DB adds
 * setup/connection failure modes that don't teach anything about LLD.
 * The repository classes built on top of this (ProblemRepository,
 * AttemptRepository, ...) expose the same find/save/findAll surface a
 * Mongoose-backed repository would, so swapping the backing store for
 * MongoDB Atlas later (as used in NCR Physio) is a change confined to
 * this one file.
 */
class JsonStore {
  constructor(filePath) {
    this.filePath = filePath;
    this.data = { problems: [], attempts: [], submissions: [], evaluations: [] };
    this._load();
  }

  _load() {
    if (fs.existsSync(this.filePath)) {
      try {
        this.data = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
      } catch {
        // Corrupt file — start clean rather than crash the server.
        this.data = { problems: [], attempts: [], submissions: [], evaluations: [] };
      }
    } else {
      fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    }
  }

  _persist() {
    fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2));
  }

  all(collection) {
    return this.data[collection] || [];
  }

  find(collection, predicate) {
    return this.all(collection).find(predicate);
  }

  filter(collection, predicate) {
    return this.all(collection).filter(predicate);
  }

  upsert(collection, item, idKey = 'id') {
    const list = this.data[collection] || (this.data[collection] = []);
    const idx = list.findIndex((i) => i[idKey] === item[idKey]);
    if (idx === -1) list.push(item);
    else list[idx] = item;
    this._persist();
    return item;
  }
}

module.exports = JsonStore;
