const express = require('express');
const path = require('path');

const JsonStore = require('./repositories/JsonStore');
const {
  ProblemRepository,
  AttemptRepository,
  SubmissionRepository,
  EvaluationRepository,
} = require('./repositories/Repositories');
const { DEFAULT_RUBRIC } = require('./domain/Rubric');
const Problem = require('./domain/Problem');
const EvaluationService = require('./services/EvaluationService');
const EvaluationQueue = require('./services/EvaluationQueue');
const AiEvaluator = require('./services/AiEvaluator');

const problemsRouter = require('./routes/problems');
const attemptsRouter = require('./routes/attempts');
const evaluationsRouter = require('./routes/evaluations');

const seedProblems = require('./data/problems.json');

/**
 * Builds a fully-wired app + its dependencies. Takes an explicit
 * `dataFile` (or `:memory:` for tests) so production and test runs
 * never share state, and an injectable `aiEvaluator` so tests can
 * swap in a fake without hitting the network.
 */
function createApp({ dataFile = path.join(__dirname, '..', 'data.json'), aiEvaluator } = {}) {
  const store = new JsonStore(dataFile === ':memory:' ? path.join(__dirname, '..', '.tmp-test-data.json') : dataFile);

  const problemRepository = new ProblemRepository(store);
  const attemptRepository = new AttemptRepository(store);
  const submissionRepository = new SubmissionRepository(store);
  const evaluationRepository = new EvaluationRepository(store);

  if (problemRepository.findAll().length === 0) {
    seedProblems.forEach((p) => problemRepository.save(new Problem(p)));
  }

  const rubric = DEFAULT_RUBRIC;
  const evaluationService = new EvaluationService({
    rubric,
    evaluators: [aiEvaluator || new AiEvaluator()],
  });
  const evaluationQueue = new EvaluationQueue({
    evaluationRepository,
    evaluationService,
    problemRepository,
    submissionRepository,
  });

  const app = express();
  app.use(express.json());
  app.use(express.static(path.join(__dirname, '..', 'public')));

  app.use('/api/problems', problemsRouter({ problemRepository }));
  app.use(
    '/api/attempts',
    attemptsRouter({ problemRepository, attemptRepository, submissionRepository, evaluationRepository, evaluationQueue, rubric }),
  );
  app.use('/api/evaluations', evaluationsRouter({ evaluationRepository, evaluationQueue, rubric }));

  app.get('/api/health', (req, res) => res.json({ ok: true }));

  return { app, store, problemRepository, attemptRepository, submissionRepository, evaluationRepository, evaluationQueue, rubric };
}

module.exports = createApp;
