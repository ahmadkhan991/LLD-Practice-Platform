/**
 * What the learner actually handed in for an Attempt.
 *
 * `format` + `sections` are deliberately generic: the domain layer
 * never parses design meaning out of the content, it just carries it.
 * Today `format` is always 'structured-text' and `sections` is a
 * Map<sectionTitle, text>. Adding a 'diagram' format later means a new
 * shape for `content` (e.g. { nodes, edges }) and a new Evaluator that
 * knows how to read it — Attempt, Problem, and Evaluation don't change
 * (this is "Change Test A" from the assignment).
 */
class Submission {
  constructor({ id, attemptId, format, sections, submittedAt }) {
    if (!id || !attemptId) {
      throw new Error('Submission requires id and attemptId');
    }
    this.id = id;
    this.attemptId = attemptId;
    this.format = format || 'structured-text';
    // sections: { [sectionTitle]: string }
    this.sections = sections || {};
    this.submittedAt = submittedAt || new Date().toISOString();
  }

  /** Concatenated text view — useful for evaluators that just want the
   * whole submission as one string (e.g. an LLM prompt). */
  fullText() {
    return Object.entries(this.sections)
      .map(([title, body]) => `## ${title}\n${body}`)
      .join('\n\n');
  }

  toJSON() {
    return {
      id: this.id,
      attemptId: this.attemptId,
      format: this.format,
      sections: this.sections,
      submittedAt: this.submittedAt,
    };
  }
}

module.exports = Submission;
