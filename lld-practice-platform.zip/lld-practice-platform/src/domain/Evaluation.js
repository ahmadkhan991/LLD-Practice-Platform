const { EvaluationStatus } = require('./EvaluationStatus');

/**
 * One CriterionResult = one row of feedback, in the shape the guide
 * recommends: criterion -> score -> evidence -> concern -> suggestion
 * -> confidence. Keeping this shape fixed (rather than free-text) is
 * what makes AI feedback "explainable" instead of a bare score.
 */
class CriterionResult {
  constructor({ criterionId, criterionName, score, evidence, concern, suggestion, confidence, evaluatorType }) {
    this.criterionId = criterionId;
    this.criterionName = criterionName;
    this.score = score; // 0..1
    this.evidence = evidence || '';
    this.concern = concern || '';
    this.suggestion = suggestion || '';
    this.confidence = confidence ?? 1;
    this.evaluatorType = evaluatorType; // 'deterministic' | 'ai'
  }
}

/**
 * The Evaluation aggregate: owns the status lifecycle and the
 * weighted overall score. Nothing outside this class computes a score
 * or flips a status — that's what keeps the queue/service code thin.
 */
class Evaluation {
  constructor({ id, submissionId, attemptId, problemId, rubricId, status, results, error, createdAt, completedAt }) {
    this.id = id;
    this.submissionId = submissionId;
    this.attemptId = attemptId;
    this.problemId = problemId;
    this.rubricId = rubricId;
    this.status = status || EvaluationStatus.SUBMITTED;
    this.results = results || [];
    this.error = error || null;
    this.createdAt = createdAt || new Date().toISOString();
    this.completedAt = completedAt || null;
  }

  markEvaluating() {
    this.status = EvaluationStatus.EVALUATING;
  }

  complete(results) {
    this.results = results;
    this.status = EvaluationStatus.COMPLETED;
    this.completedAt = new Date().toISOString();
  }

  fail(error) {
    this.error = error?.message || String(error);
    this.status = EvaluationStatus.FAILED;
    this.completedAt = new Date().toISOString();
  }

  /** Weighted overall score from whatever results exist so far. Lets a
   * FAILED-after-partial-progress evaluation still show something useful
   * instead of nothing. */
  overallScore(rubric) {
    if (this.results.length === 0) return null;
    const byId = new Map(rubric.criteria.map((c) => [c.id, c]));
    let weightedSum = 0;
    let weightTotal = 0;
    for (const r of this.results) {
      const criterion = byId.get(r.criterionId);
      const weight = criterion ? criterion.weight : 0;
      weightedSum += r.score * weight;
      weightTotal += weight;
    }
    return weightTotal > 0 ? +(weightedSum / weightTotal).toFixed(3) : null;
  }

  toJSON(rubric) {
    return {
      id: this.id,
      submissionId: this.submissionId,
      attemptId: this.attemptId,
      problemId: this.problemId,
      rubricId: this.rubricId,
      status: this.status,
      results: this.results,
      overallScore: rubric ? this.overallScore(rubric) : null,
      error: this.error,
      createdAt: this.createdAt,
      completedAt: this.completedAt,
    };
  }
}

module.exports = { Evaluation, CriterionResult };
