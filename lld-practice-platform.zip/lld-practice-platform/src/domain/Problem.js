/**
 * A practice problem (e.g. "Parking Lot"). Immutable-ish value object —
 * problems are seeded, not authored through the API, in this MVP.
 *
 * `requiredSections` drives BOTH the submission form the learner fills
 * in AND the deterministic structural check, so the two can never
 * silently drift apart.
 */
class Problem {
  constructor({ id, title, description, requirements, constraints, requiredSections }) {
    if (!id || !title || !description) {
      throw new Error('Problem requires id, title, and description');
    }
    this.id = id;
    this.title = title;
    this.description = description;
    this.requirements = requirements || [];
    this.constraints = constraints || [];
    // Sections a well-formed submission must address for this problem.
    this.requiredSections = requiredSections || [
      'Classes & Responsibilities',
      'Relationships',
      'Extensibility',
      'Edge Cases & Trade-offs',
    ];
  }

  toJSON() {
    return {
      id: this.id,
      title: this.title,
      description: this.description,
      requirements: this.requirements,
      constraints: this.constraints,
      requiredSections: this.requiredSections,
    };
  }
}

module.exports = Problem;
