/**
 * Lifecycle of an Evaluation. Kept as a small closed set so state
 * transitions are easy to validate and reason about.
 *
 *   SUBMITTED  -> EVALUATING -> COMPLETED
 *                            -> FAILED
 *
 * A submission is persisted (status SUBMITTED) *before* any evaluator
 * runs, so a crashed/slow evaluator never loses the learner's work.
 */
const EvaluationStatus = Object.freeze({
  SUBMITTED: 'SUBMITTED',
  EVALUATING: 'EVALUATING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
});

const TERMINAL_STATUSES = new Set([
  EvaluationStatus.COMPLETED,
  EvaluationStatus.FAILED,
]);

function isTerminal(status) {
  return TERMINAL_STATUSES.has(status);
}

module.exports = { EvaluationStatus, isTerminal };
