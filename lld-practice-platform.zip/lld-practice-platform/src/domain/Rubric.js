/**
 * A Criterion is one axis of judgement (e.g. "Class Responsibilities").
 * `evaluatorType` tags which kind of Evaluator owns it — this is the
 * single place that decides "deterministic vs AI" per the assignment's
 * design question, rather than that decision being buried in code.
 */
class Criterion {
  constructor({ id, name, description, weight, evaluatorType }) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.weight = weight; // 0..1, all criteria in a rubric should sum to ~1
    this.evaluatorType = evaluatorType; // 'deterministic' | 'ai'
  }
}

/**
 * A named set of Criteria. One rubric is shared by every problem in
 * this MVP (the dimensions of "good LLD" don't change per-problem);
 * problem-specific context is injected into the AI prompt instead of
 * forking the rubric. A future rubric-per-problem-category would just
 * mean RubricRepository keying by problem instead of a singleton.
 */
class Rubric {
  constructor({ id, name, criteria }) {
    this.id = id;
    this.name = name;
    this.criteria = criteria || [];
  }

  deterministicCriteria() {
    return this.criteria.filter((c) => c.evaluatorType === 'deterministic');
  }

  aiCriteria() {
    return this.criteria.filter((c) => c.evaluatorType === 'ai');
  }
}

const DEFAULT_RUBRIC = new Rubric({
  id: 'default-lld-rubric',
  name: 'General LLD Rubric',
  criteria: [
    new Criterion({
      id: 'structure-completeness',
      name: 'Structural Completeness',
      description: 'All required sections are present and non-trivial.',
      weight: 0.15,
      evaluatorType: 'deterministic',
    }),
    new Criterion({
      id: 'requirement-coverage',
      name: 'Requirement Understanding',
      description: 'The design addresses the stated requirements and constraints.',
      weight: 0.15,
      evaluatorType: 'ai',
    }),
    new Criterion({
      id: 'responsibilities',
      name: 'Class Responsibilities',
      description: 'Each class/interface has a single, clear responsibility.',
      weight: 0.2,
      evaluatorType: 'ai',
    }),
    new Criterion({
      id: 'coupling-cohesion',
      name: 'Coupling / Cohesion',
      description: 'Components are loosely coupled and internally cohesive.',
      weight: 0.15,
      evaluatorType: 'ai',
    }),
    new Criterion({
      id: 'extensibility',
      name: 'Extensibility',
      description: 'The design accommodates plausible future changes without a rewrite.',
      weight: 0.2,
      evaluatorType: 'ai',
    }),
    new Criterion({
      id: 'edge-cases',
      name: 'Edge Cases & Testability',
      description: 'Edge cases are identified and the design is testable.',
      weight: 0.15,
      evaluatorType: 'ai',
    }),
  ],
});

module.exports = { Rubric, Criterion, DEFAULT_RUBRIC };
