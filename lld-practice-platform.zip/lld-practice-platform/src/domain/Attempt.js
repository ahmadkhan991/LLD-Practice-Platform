/**
 * One learner's try at one Problem. An Attempt can hold at most one
 * "live" Submission at a time in this MVP (retrying starts a new
 * Attempt), which keeps history simple: history = list of Attempts,
 * each with its Submission + Evaluation attached.
 */
class Attempt {
  constructor({ id, problemId, learnerId, createdAt }) {
    if (!id || !problemId) {
      throw new Error('Attempt requires id and problemId');
    }
    this.id = id;
    this.problemId = problemId;
    // No auth in this MVP — a single fixed learner keeps scope on the
    // practice loop rather than an account system. Swapping in real
    // learners means threading a real learnerId through the same field.
    this.learnerId = learnerId || 'guest-learner';
    this.createdAt = createdAt || new Date().toISOString();
  }

  toJSON() {
    return {
      id: this.id,
      problemId: this.problemId,
      learnerId: this.learnerId,
      createdAt: this.createdAt,
    };
  }
}

module.exports = Attempt;
