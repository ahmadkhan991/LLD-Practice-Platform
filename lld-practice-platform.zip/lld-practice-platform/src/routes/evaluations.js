const express = require('express');
const { EvaluationStatus } = require('../domain/EvaluationStatus');

function evaluationsRouter({ evaluationRepository, evaluationQueue, rubric }) {
  const router = express.Router();

  // Learner polls this while status is SUBMITTED/EVALUATING.
  router.get('/:id', (req, res) => {
    const evaluation = evaluationRepository.findById(req.params.id);
    if (!evaluation) return res.status(404).json({ error: 'Evaluation not found' });
    res.json(evaluation.toJSON(rubric));
  });

  // Re-run a FAILED evaluation. enqueue() is idempotent, so calling
  // this on an already-running or already-completed evaluation is a
  // harmless no-op — safe for a learner double-clicking "retry".
  router.post('/:id/retry', (req, res) => {
    const evaluation = evaluationRepository.findById(req.params.id);
    if (!evaluation) return res.status(404).json({ error: 'Evaluation not found' });
    if (evaluation.status === EvaluationStatus.FAILED) {
      evaluation.status = EvaluationStatus.SUBMITTED;
      evaluation.error = null;
      evaluationRepository.save(evaluation);
    }
    evaluationQueue.enqueue(evaluation.id);
    res.json(evaluation.toJSON(rubric));
  });

  return router;
}

module.exports = evaluationsRouter;
