const express = require('express');

function problemsRouter({ problemRepository }) {
  const router = express.Router();

  router.get('/', (req, res) => {
    res.json(problemRepository.findAll().map((p) => p.toJSON()));
  });

  router.get('/:id', (req, res) => {
    const problem = problemRepository.findById(req.params.id);
    if (!problem) return res.status(404).json({ error: 'Problem not found' });
    res.json(problem.toJSON());
  });

  return router;
}

module.exports = problemsRouter;
