const express = require('express');
const crypto = require('crypto');
const Attempt = require('../domain/Attempt');
const Submission = require('../domain/Submission');
const { Evaluation } = require('../domain/Evaluation');

const GUEST_LEARNER = 'guest-learner'; // single-learner MVP, see Attempt.js

function attemptsRouter({ problemRepository, attemptRepository, submissionRepository, evaluationRepository, evaluationQueue, rubric }) {
  const router = express.Router();

  // Start a new attempt at a problem.
  router.post('/', (req, res) => {
    const { problemId } = req.body || {};
    const problem = problemId && problemRepository.findById(problemId);
    if (!problem) return res.status(400).json({ error: 'Valid problemId is required' });

    const attempt = new Attempt({ id: crypto.randomUUID(), problemId, learnerId: GUEST_LEARNER });
    attemptRepository.save(attempt);
    res.status(201).json({ attempt: attempt.toJSON(), problem: problem.toJSON() });
  });

  // Attempt history for the (single, MVP) learner — most recent first.
  router.get('/', (req, res) => {
    const attempts = attemptRepository.findByLearner(GUEST_LEARNER);
    const enriched = attempts.map((attempt) => {
      const submissions = submissionRepository.findByAttempt(attempt.id);
      const latestSubmission = submissions[submissions.length - 1] || null;
      const evaluation = latestSubmission ? evaluationRepository.findBySubmission(latestSubmission.id) : null;
      const problem = problemRepository.findById(attempt.problemId);
      return {
        attempt: attempt.toJSON(),
        problemTitle: problem ? problem.title : attempt.problemId,
        hasSubmission: Boolean(latestSubmission),
        evaluation: evaluation ? evaluation.toJSON(rubric) : null,
      };
    });
    res.json(enriched);
  });

  router.get('/:id', (req, res) => {
    const attempt = attemptRepository.findById(req.params.id);
    if (!attempt) return res.status(404).json({ error: 'Attempt not found' });
    const problem = problemRepository.findById(attempt.problemId);
    const submissions = submissionRepository.findByAttempt(attempt.id);
    const latestSubmission = submissions[submissions.length - 1] || null;
    const evaluation = latestSubmission ? evaluationRepository.findBySubmission(latestSubmission.id) : null;
    res.json({
      attempt: attempt.toJSON(),
      problem: problem ? problem.toJSON() : null,
      submission: latestSubmission ? latestSubmission.toJSON() : null,
      evaluation: evaluation ? evaluation.toJSON(rubric) : null,
    });
  });

  // Submit a solution for an attempt. Persists immediately, then hands
  // evaluation off to the queue and returns without waiting for it.
  router.post('/:id/submissions', (req, res) => {
    const attempt = attemptRepository.findById(req.params.id);
    if (!attempt) return res.status(404).json({ error: 'Attempt not found' });

    const problem = problemRepository.findById(attempt.problemId);
    const { sections } = req.body || {};
    if (!sections || typeof sections !== 'object') {
      return res.status(400).json({ error: 'sections object is required' });
    }

    const submission = new Submission({ id: crypto.randomUUID(), attemptId: attempt.id, sections });
    submissionRepository.save(submission);

    // Evaluation row is created (and persisted) BEFORE the queue runs
    // anything, so the submission is never lost even if evaluation
    // crashes or the process restarts mid-run.
    const evaluation = new Evaluation({
      id: crypto.randomUUID(),
      submissionId: submission.id,
      attemptId: attempt.id,
      problemId: problem.id,
      rubricId: rubric.id,
    });
    evaluationRepository.save(evaluation);
    evaluationQueue.enqueue(evaluation.id);

    res.status(202).json({ submission: submission.toJSON(), evaluation: evaluation.toJSON(rubric) });
  });

  return router;
}

module.exports = attemptsRouter;
