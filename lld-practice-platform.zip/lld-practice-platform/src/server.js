const createApp = require('./app');

const PORT = process.env.PORT || 3000;
const { app } = createApp();

app.listen(PORT, () => {
  console.log(`LLD Practice Platform listening on http://localhost:${PORT}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.log('ANTHROPIC_API_KEY not set — AI evaluation will run in mock/heuristic mode.');
  }
});
