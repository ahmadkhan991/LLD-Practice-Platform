const { CriterionResult } = require('../domain/Evaluation');

const MIN_SECTION_CHARS = 40;

/**
 * Checks structure, not quality: are the required sections present
 * and non-trivial? This runs first and for free, so an empty or
 * placeholder submission never reaches the AI evaluator — it fails
 * fast with a precise, actionable message instead of an expensive and
 * vague "AI says this is incomplete."
 *
 * This is also what answers "what should evaluation look at that
 * doesn't need judgement at all" from the guide's deterministic/AI
 * split table.
 */
class DeterministicEvaluator {
  constructor() {
    this.name = 'deterministic';
  }

  supports(submission) {
    return submission.format === 'structured-text';
  }

  async evaluate(submission, problem, criteria) {
    const criterion = criteria.find((c) => c.id === 'structure-completeness');
    if (!criterion) return [];

    const missing = [];
    const thin = [];
    for (const section of problem.requiredSections) {
      const text = (submission.sections[section] || '').trim();
      if (text.length === 0) missing.push(section);
      else if (text.length < MIN_SECTION_CHARS) thin.push(section);
    }

    const total = problem.requiredSections.length;
    // A missing section is penalized twice as hard as a thin one — the
    // gate exists to catch "didn't even attempt this part", which a
    // thin-but-present section hasn't done.
    const penalty = missing.length * 2 + thin.length * 1;
    const score = total === 0 ? 1 : Math.max(0, (total - penalty) / total);

    let evidence = 'All required sections are present and reasonably detailed.';
    let concern = '';
    let suggestion = '';
    if (missing.length > 0) {
      concern = `Missing section(s): ${missing.join(', ')}.`;
      suggestion = `Add the missing section(s) — evaluators (including the AI reviewer) can't assess what isn't written down.`;
      evidence = `${missing.length} of ${total} required sections are empty.`;
    } else if (thin.length > 0) {
      concern = `Very short section(s): ${thin.join(', ')}.`;
      suggestion = `Expand these sections with more concrete detail (classes, methods, reasoning).`;
      evidence = `${thin.length} of ${total} required sections are under ${MIN_SECTION_CHARS} characters.`;
    }

    return [
      new CriterionResult({
        criterionId: criterion.id,
        criterionName: criterion.name,
        score,
        evidence,
        concern,
        suggestion,
        confidence: 1,
        evaluatorType: 'deterministic',
      }),
    ];
  }

  /** Used by EvaluationService to decide whether it's even worth
   * calling the (slower, costlier) AI evaluator. */
  static passesGate(results) {
    return results.every((r) => r.score >= 0.5);
  }
}

module.exports = DeterministicEvaluator;
