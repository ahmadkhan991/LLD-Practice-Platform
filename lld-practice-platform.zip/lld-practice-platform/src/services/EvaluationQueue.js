const { EvaluationStatus, isTerminal } = require('../domain/EvaluationStatus');

/**
 * Deliberately NOT a distributed queue (SQS/Redis/etc) — the
 * assignment explicitly asks to keep this practical. It IS a real
 * answer to the assignment's async questions though:
 *
 *   - "store before evaluation starts": the Evaluation row is created
 *     with status SUBMITTED synchronously, before enqueue() returns.
 *   - "don't block the request": processing happens on the next tick
 *     (setImmediate), the HTTP handler returns immediately with
 *     status SUBMITTED and the learner polls GET /evaluations/:id.
 *   - "avoid duplicate processing on retry": enqueue() is idempotent
 *     per evaluationId — a retried request for the same evaluation is
 *     a no-op if it's already queued/running/terminal.
 *   - "what if evaluation fails": errors are caught and turn into
 *     status FAILED with a message, never an unhandled crash.
 *
 * In a real deployment with multiple instances, swap this class's
 * internals for a real broker (BullMQ, SQS) behind the exact same
 * enqueue()/onProcessed() surface — EvaluationRoutes and
 * EvaluationService would not need to change.
 */
class EvaluationQueue {
  constructor({ evaluationRepository, evaluationService, problemRepository, submissionRepository }) {
    this.evaluationRepository = evaluationRepository;
    this.evaluationService = evaluationService;
    this.problemRepository = problemRepository;
    this.submissionRepository = submissionRepository;
    this.inFlight = new Set(); // evaluationIds currently being processed
  }

  enqueue(evaluationId) {
    if (this.inFlight.has(evaluationId)) return; // idempotent

    const evaluation = this.evaluationRepository.findById(evaluationId);
    if (!evaluation || isTerminal(evaluation.status)) return; // already done

    this.inFlight.add(evaluationId);
    setImmediate(() => this._process(evaluationId));
  }

  async _process(evaluationId) {
    try {
      const evaluation = this.evaluationRepository.findById(evaluationId);
      if (!evaluation) return;

      evaluation.markEvaluating();
      this.evaluationRepository.save(evaluation);

      const submission = this.submissionRepository.findById(evaluation.submissionId);
      const problem = this.problemRepository.findById(evaluation.problemId);

      const results = await this.evaluationService.run(submission, problem);

      evaluation.complete(results);
      this.evaluationRepository.save(evaluation);
    } catch (err) {
      const evaluation = this.evaluationRepository.findById(evaluationId);
      if (evaluation) {
        evaluation.status = EvaluationStatus.FAILED;
        evaluation.fail(err);
        this.evaluationRepository.save(evaluation);
      }
    } finally {
      this.inFlight.delete(evaluationId);
    }
  }
}

module.exports = EvaluationQueue;
