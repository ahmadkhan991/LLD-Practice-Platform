const { assertIsEvaluator } = require('./IEvaluator');
const DeterministicEvaluator = require('./DeterministicEvaluator');

/**
 * Runs a submission through the deterministic gate, then (only if the
 * gate passes) through every registered evaluator that supports the
 * submission's format. This single method is the answer to "which
 * parts should be deterministic and which benefit from an LLM": the
 * decision lives here, once, instead of being scattered across routes.
 *
 * Adding a new evaluator (rule-based-v2, human review, a second LLM)
 * is `service.register(newEvaluator)` — nothing else in this file, the
 * routes, or the queue needs to change (Change Test B).
 */
class EvaluationService {
  constructor({ rubric, evaluators = [] } = {}) {
    this.rubric = rubric;
    this.deterministic = new DeterministicEvaluator();
    this.evaluators = [];
    evaluators.forEach((e) => this.register(e));
  }

  register(evaluator) {
    assertIsEvaluator(evaluator);
    this.evaluators.push(evaluator);
  }

  async run(submission, problem) {
    const deterministicResults = await this.deterministic.evaluate(
      submission,
      problem,
      this.rubric.deterministicCriteria(),
    );

    if (!DeterministicEvaluator.passesGate(deterministicResults)) {
      // Fail fast: don't spend AI evaluator time/cost on a submission
      // that doesn't even have its required sections filled in.
      return deterministicResults;
    }

    const aiCriteria = this.rubric.aiCriteria();
    const applicable = this.evaluators.filter((e) => e.supports(submission));
    const aiResultLists = await Promise.all(
      applicable.map((e) => e.evaluate(submission, problem, aiCriteria)),
    );

    return [...deterministicResults, ...aiResultLists.flat()];
  }
}

module.exports = EvaluationService;
