const { CriterionResult } = require('../domain/Evaluation');
const MockAiEvaluator = require('./MockAiEvaluator');

const API_URL = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-6';

function buildPrompt(submission, problem, criteria) {
  const criteriaList = criteria
    .map((c) => `- id: "${c.id}", name: "${c.name}", what to look for: ${c.description}`)
    .join('\n');

  return `You are grading a Low-Level Design (LLD) practice submission. There is no single correct
answer — judge the design on its own merits against the rubric below, and cite concrete
evidence from the submission for every score.

# Problem: ${problem.title}
${problem.description}

Requirements:
${problem.requirements.map((r) => `- ${r}`).join('\n')}

Constraints:
${problem.constraints.map((c) => `- ${c}`).join('\n')}

# Rubric (score each 0.0-1.0)
${criteriaList}

# Submission
${submission.fullText()}

# Output format
Respond with ONLY a JSON array, no prose, no markdown fences. One object per rubric
criterion above, in this exact shape:
[
  {
    "criterionId": "<id from rubric>",
    "score": <0.0-1.0>,
    "evidence": "<specific evidence from the submission>",
    "concern": "<the main gap, or empty string if none>",
    "suggestion": "<one concrete, actionable improvement>",
    "confidence": <0.0-1.0, how confident you are in this score>
  }
]`;
}

function parseModelJson(text) {
  const cleaned = text.trim().replace(/^```json\s*/i, '').replace(/```$/, '');
  const parsed = JSON.parse(cleaned);
  if (!Array.isArray(parsed)) throw new Error('Model output was not a JSON array');
  return parsed;
}

/**
 * Real LLM-backed evaluator for the judgement-heavy rubric criteria
 * (design quality, trade-offs, extensibility — the things the guide
 * says are "good candidates for AI").
 *
 * Falls back to MockAiEvaluator when:
 *   - no ANTHROPIC_API_KEY is set (so the prototype runs out of the box)
 *   - the API call fails, times out, or returns malformed JSON
 * This fallback is a deliberate reliability choice, not a hidden
 * failure: EvaluationQueue logs which path was taken, and it is
 * covered by a test (see ai-evaluator fallback behaviour).
 */
class AiEvaluator {
  constructor({ apiKey = process.env.ANTHROPIC_API_KEY, timeoutMs = 20000, fetchImpl = globalThis.fetch } = {}) {
    this.name = 'ai';
    this.apiKey = apiKey;
    this.timeoutMs = timeoutMs;
    this.fetchImpl = fetchImpl;
    this.mock = new MockAiEvaluator();
  }

  supports(submission) {
    return submission.format === 'structured-text';
  }

  async evaluate(submission, problem, criteria) {
    const aiCriteria = criteria.filter((c) => c.evaluatorType === 'ai');
    if (aiCriteria.length === 0) return [];

    if (!this.apiKey) {
      return this.mock.evaluate(submission, problem, criteria);
    }

    try {
      const raw = await this._callModel(submission, problem, aiCriteria);
      const byId = new Map(aiCriteria.map((c) => [c.id, c]));
      const results = raw
        .filter((item) => byId.has(item.criterionId))
        .map((item) => {
          const criterion = byId.get(item.criterionId);
          return new CriterionResult({
            criterionId: criterion.id,
            criterionName: criterion.name,
            score: Math.max(0, Math.min(1, Number(item.score) || 0)),
            evidence: item.evidence || '',
            concern: item.concern || '',
            suggestion: item.suggestion || '',
            confidence: item.confidence ?? 0.7,
            evaluatorType: 'ai',
          });
        });
      // If the model dropped some criteria, fill the rest from the mock
      // rather than silently under-reporting.
      const covered = new Set(results.map((r) => r.criterionId));
      const missingCriteria = aiCriteria.filter((c) => !covered.has(c.id));
      if (missingCriteria.length > 0) {
        const fallbackResults = await this.mock.evaluate(submission, problem, missingCriteria);
        return [...results, ...fallbackResults];
      }
      return results;
    } catch (err) {
      // Reliability over completeness: never let an LLM hiccup fail the
      // whole evaluation when a usable (if weaker) result is available.
      return this.mock.evaluate(submission, problem, criteria);
    }
  }

  async _callModel(submission, problem, criteria) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetchImpl(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: 1500,
          messages: [{ role: 'user', content: buildPrompt(submission, problem, criteria) }],
        }),
        signal: controller.signal,
      });
      if (!response.ok) {
        throw new Error(`Anthropic API returned ${response.status}`);
      }
      const data = await response.json();
      const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
      return parseModelJson(text);
    } finally {
      clearTimeout(timeout);
    }
  }
}

module.exports = AiEvaluator;
