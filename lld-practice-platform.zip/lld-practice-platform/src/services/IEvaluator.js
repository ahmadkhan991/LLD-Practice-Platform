/**
 * The Evaluator "interface" every evaluator strategy must satisfy.
 * JS has no interfaces, so this is enforced by convention + a runtime
 * check in EvaluationService.register(). This is the seam the
 * assignment's two change-tests are aimed at:
 *
 *   - Change Test A (new submission format): a new evaluator can
 *     declare supports(submission) === false for formats it can't
 *     read, and EvaluationService just skips it — no changes needed
 *     to Attempt/Submission/Evaluation or the practice flow.
 *   - Change Test B (new evaluator, e.g. rule-based-v2 or human
 *     review): implement this interface and register() it. Existing
 *     evaluators, routes, and the queue are untouched.
 *
 * @interface
 * name            {string} unique id, e.g. 'deterministic' | 'ai'
 * supports(submission)          {boolean}
 * evaluate(submission, problem, criteria) -> Promise<CriterionResult[]>
 */

function assertIsEvaluator(evaluator) {
  const missing = ['name', 'supports', 'evaluate'].filter((k) => typeof evaluator[k] === 'undefined');
  if (missing.length > 0) {
    throw new Error(`Evaluator is missing required member(s): ${missing.join(', ')}`);
  }
}

module.exports = { assertIsEvaluator };
