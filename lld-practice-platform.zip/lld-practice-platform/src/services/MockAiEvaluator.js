const { CriterionResult } = require('../domain/Evaluation');

const OOP_SIGNAL_WORDS = ['class', 'interface', 'implements', 'extends', 'responsibility', 'encapsulat'];
const EXTENSIBILITY_WORDS = ['extend', 'add a new', 'plug', 'strategy', 'factory', 'observer', 'decouple', 'interface'];
const EDGE_CASE_WORDS = ['edge case', 'what if', 'fails', 'failure', 'concurrent', 'race', 'null', 'invalid', 'full', 'empty'];

function scoreFromSignals(text, words) {
  const lower = text.toLowerCase();
  const hits = words.filter((w) => lower.includes(w)).length;
  return Math.min(1, 0.35 + hits * 0.15);
}

/**
 * Heuristic stand-in for a real LLM call: keyword/length signals per
 * criterion, mapped into the SAME CriterionResult shape a real model
 * would return. This exists so the prototype is demonstrable without
 * an API key, and so AIEvaluator has something safe to fall back to
 * if the real API call errors or times out (see AIEvaluator.js).
 *
 * It is intentionally NOT trying to be a good evaluator — it is a
 * contract-compatible placeholder. Swapping it for a stronger local
 * model is possible without touching EvaluationService.
 */
class MockAiEvaluator {
  constructor() {
    this.name = 'mock-ai';
  }

  supports(submission) {
    return submission.format === 'structured-text';
  }

  async evaluate(submission, problem, criteria) {
    const text = submission.fullText();
    const wordCount = text.split(/\s+/).filter(Boolean).length;
    const lengthFactor = Math.min(1, wordCount / 150);

    return criteria
      .filter((c) => c.evaluatorType === 'ai')
      .map((criterion) => {
        let score;
        let evidence;
        let suggestion;
        if (criterion.id === 'extensibility') {
          score = scoreFromSignals(text, EXTENSIBILITY_WORDS) * lengthFactor;
          evidence = 'Looked for explicit discussion of how the design would absorb new requirements.';
          suggestion = 'Name a concrete future change and walk through exactly which class(es) would change.';
        } else if (criterion.id === 'edge-cases') {
          score = scoreFromSignals(text, EDGE_CASE_WORDS) * lengthFactor;
          evidence = 'Looked for explicit edge cases or failure scenarios in the Edge Cases section.';
          suggestion = 'List 2-3 concrete edge cases (e.g. capacity full, invalid input, concurrent access) and how the design handles each.';
        } else if (criterion.id === 'responsibilities' || criterion.id === 'coupling-cohesion') {
          score = scoreFromSignals(text, OOP_SIGNAL_WORDS) * lengthFactor;
          evidence = 'Looked for named classes/interfaces with stated responsibilities and relationships.';
          suggestion = 'For each class, write one sentence on the single responsibility it owns and what it depends on.';
        } else {
          score = 0.4 + 0.4 * lengthFactor;
          evidence = 'Compared submission length/detail against the problem requirements.';
          suggestion = 'Reference specific requirements from the problem statement by name.';
        }
        score = Math.max(0, Math.min(1, +score.toFixed(2)));
        return new CriterionResult({
          criterionId: criterion.id,
          criterionName: criterion.name,
          score,
          evidence,
          concern: score < 0.6 ? `Limited evidence found for "${criterion.name}".` : '',
          suggestion,
          confidence: 0.4, // deliberately low — this is a heuristic stand-in, not a real review
          evaluatorType: 'ai',
        });
      });
  }
}

module.exports = MockAiEvaluator;
