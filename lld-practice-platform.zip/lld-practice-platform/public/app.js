const API = '/api';

const els = {
  navPractice: document.getElementById('nav-practice'),
  navHistory: document.getElementById('nav-history'),
  viewPractice: document.getElementById('view-practice'),
  viewHistory: document.getElementById('view-history'),

  problemListPanel: document.getElementById('problem-list-panel'),
  problemList: document.getElementById('problem-list'),

  problemDetailPanel: document.getElementById('problem-detail-panel'),
  problemTitle: document.getElementById('problem-title'),
  problemDescription: document.getElementById('problem-description'),
  problemRequirements: document.getElementById('problem-requirements'),
  problemConstraints: document.getElementById('problem-constraints'),
  startAttemptBtn: document.getElementById('start-attempt-btn'),
  backToProblems: document.getElementById('back-to-problems'),

  attemptPanel: document.getElementById('attempt-panel'),
  attemptProblemTitle: document.getElementById('attempt-problem-title'),
  submissionForm: document.getElementById('submission-form'),
  submitBtn: document.getElementById('submit-btn'),
  submissionStatus: document.getElementById('submission-status'),
  feedbackBox: document.getElementById('feedback-box'),
  backToProblem: document.getElementById('back-to-problem'),

  historyList: document.getElementById('history-list'),
};

let state = { problems: [], selectedProblem: null, currentAttemptId: null, pollTimer: null };

async function api(path, options) {
  const res = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

// ---------- Navigation ----------
function showView(name) {
  els.viewPractice.classList.toggle('hidden', name !== 'practice');
  els.viewHistory.classList.toggle('hidden', name !== 'history');
  els.navPractice.classList.toggle('active', name === 'practice');
  els.navHistory.classList.toggle('active', name === 'history');
  if (name === 'history') loadHistory();
}
els.navPractice.addEventListener('click', () => showView('practice'));
els.navHistory.addEventListener('click', () => showView('history'));

function showPracticeStep(step) {
  els.problemListPanel.classList.toggle('hidden', step !== 'list');
  els.problemDetailPanel.classList.toggle('hidden', step !== 'detail');
  els.attemptPanel.classList.toggle('hidden', step !== 'attempt');
}

// ---------- Problem list & detail ----------
async function loadProblems() {
  state.problems = await api('/problems');
  els.problemList.innerHTML = state.problems
    .map((p) => `<div class="problem-card" data-id="${p.id}"><h3>${p.title}</h3><p>${p.description}</p></div>`)
    .join('');
  els.problemList.querySelectorAll('.problem-card').forEach((card) => {
    card.addEventListener('click', () => openProblem(card.dataset.id));
  });
}

function openProblem(id) {
  const problem = state.problems.find((p) => p.id === id);
  state.selectedProblem = problem;
  els.problemTitle.textContent = problem.title;
  els.problemDescription.textContent = problem.description;
  els.problemRequirements.innerHTML = problem.requirements.map((r) => `<li>${r}</li>`).join('');
  els.problemConstraints.innerHTML = problem.constraints.map((c) => `<li>${c}</li>`).join('');
  showPracticeStep('detail');
}
els.backToProblems.addEventListener('click', () => showPracticeStep('list'));

// ---------- Attempt & submission ----------
els.startAttemptBtn.addEventListener('click', async () => {
  const { attempt, problem } = await api('/attempts', {
    method: 'POST',
    body: JSON.stringify({ problemId: state.selectedProblem.id }),
  });
  state.currentAttemptId = attempt.id;
  openAttempt(problem);
});
els.backToProblem.addEventListener('click', () => {
  clearTimeout(state.pollTimer);
  showPracticeStep('detail');
});

function openAttempt(problem) {
  els.attemptProblemTitle.textContent = `${problem.title} — new attempt`;
  els.submissionForm.innerHTML = problem.requiredSections
    .map(
      (section) => `
      <div class="section-field">
        <label for="section-${slug(section)}">${section}</label>
        <textarea id="section-${slug(section)}" data-section="${section}" placeholder="Write your ${section.toLowerCase()} here..."></textarea>
      </div>`,
    )
    .join('');
  els.feedbackBox.classList.add('hidden');
  els.feedbackBox.innerHTML = '';
  els.submissionStatus.classList.add('hidden');
  els.submitBtn.disabled = false;
  showPracticeStep('attempt');
}

function slug(s) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-');
}

els.submitBtn.addEventListener('click', async () => {
  const sections = {};
  els.submissionForm.querySelectorAll('textarea').forEach((t) => {
    sections[t.dataset.section] = t.value;
  });

  els.submitBtn.disabled = true;
  els.submissionStatus.classList.remove('hidden');
  els.submissionStatus.textContent = 'Submitting...';
  els.feedbackBox.classList.add('hidden');

  try {
    const { evaluation } = await api(`/attempts/${state.currentAttemptId}/submissions`, {
      method: 'POST',
      body: JSON.stringify({ sections }),
    });
    pollEvaluation(evaluation.id);
  } catch (err) {
    els.submissionStatus.textContent = `Error: ${err.message}`;
    els.submitBtn.disabled = false;
  }
});

function pollEvaluation(evaluationId) {
  els.submissionStatus.textContent = 'Status: SUBMITTED — waiting to be evaluated...';
  const poll = async () => {
    const evaluation = await api(`/evaluations/${evaluationId}`);
    els.submissionStatus.textContent = `Status: ${evaluation.status}`;
    if (evaluation.status === 'COMPLETED' || evaluation.status === 'FAILED') {
      els.submitBtn.disabled = false;
      renderFeedback(evaluation);
      return;
    }
    state.pollTimer = setTimeout(poll, 500);
  };
  poll();
}

function renderFeedback(evaluation) {
  els.feedbackBox.classList.remove('hidden');
  if (evaluation.status === 'FAILED') {
    els.feedbackBox.innerHTML = `<div class="score-banner score-bad">Evaluation failed: ${evaluation.error}</div>
      <button class="primary-btn" id="retry-btn">Retry evaluation</button>`;
    document.getElementById('retry-btn').addEventListener('click', async () => {
      const evalNow = await api(`/evaluations/${evaluation.id}/retry`, { method: 'POST' });
      pollEvaluation(evalNow.id);
    });
    return;
  }

  const score = evaluation.overallScore ?? 0;
  const scoreClass = score >= 0.7 ? 'score-good' : score >= 0.4 ? 'score-mid' : 'score-bad';
  const criteriaHtml = evaluation.results
    .map(
      (r) => `
      <div class="criterion-card">
        <div class="criterion-head">
          <strong>${r.criterionName || r.criterionId}<span class="tag">${r.evaluatorType}</span></strong>
          <span class="criterion-score">${Math.round(r.score * 100)}%</span>
        </div>
        ${r.evidence ? `<p><b>Evidence:</b> ${r.evidence}</p>` : ''}
        ${r.concern ? `<p><b>Concern:</b> ${r.concern}</p>` : ''}
        ${r.suggestion ? `<p><b>Suggestion:</b> ${r.suggestion}</p>` : ''}
      </div>`,
    )
    .join('');

  els.feedbackBox.innerHTML = `
    <div class="score-banner ${scoreClass}">Overall score: ${Math.round(score * 100)}%</div>
    ${criteriaHtml}`;
}

// ---------- History ----------
async function loadHistory() {
  const items = await api('/attempts');
  if (items.length === 0) {
    els.historyList.innerHTML = '<p style="color:var(--muted)">No attempts yet — start one from the Practice tab.</p>';
    return;
  }
  els.historyList.innerHTML = items
    .map((item) => {
      const score = item.evaluation && item.evaluation.overallScore != null
        ? `${Math.round(item.evaluation.overallScore * 100)}%`
        : '—';
      const status = item.evaluation ? item.evaluation.status : 'No submission';
      return `<div class="history-item">
        <div>
          <div><strong>${item.problemTitle}</strong></div>
          <div class="meta">${new Date(item.attempt.createdAt).toLocaleString()}</div>
        </div>
        <div style="text-align:right">
          <span class="status-pill">${status}</span>
          <div class="meta">Score: ${score}</div>
        </div>
      </div>`;
    })
    .join('');
}

loadProblems();
