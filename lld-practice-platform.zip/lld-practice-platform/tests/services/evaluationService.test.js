const EvaluationService = require('../../src/services/EvaluationService');
const Problem = require('../../src/domain/Problem');
const Submission = require('../../src/domain/Submission');
const { Rubric, Criterion } = require('../../src/domain/Rubric');
const { CriterionResult } = require('../../src/domain/Evaluation');

const rubric = new Rubric({
  id: 'r1',
  criteria: [
    new Criterion({ id: 'structure-completeness', name: 'Structure', weight: 0.5, evaluatorType: 'deterministic' }),
    new Criterion({ id: 'quality', name: 'Quality', weight: 0.5, evaluatorType: 'ai' }),
  ],
});

const problem = new Problem({
  id: 'p1',
  title: 'Test',
  description: 'desc',
  requiredSections: ['Only Section'],
});

function makeFakeEvaluator(name, { supports = true } = {}) {
  return {
    name,
    calls: 0,
    supports: () => supports,
    async evaluate(submission, prob, criteria) {
      this.calls += 1;
      return criteria.map(
        (c) => new CriterionResult({ criterionId: c.id, criterionName: c.name, score: 0.9, evaluatorType: 'ai' }),
      );
    },
  };
}

test('skips AI evaluators entirely when the deterministic gate fails', async () => {
  const fakeAi = makeFakeEvaluator('fake-ai');
  const service = new EvaluationService({ rubric, evaluators: [fakeAi] });
  const emptySubmission = new Submission({ id: 's1', attemptId: 'a1', sections: {} });

  const results = await service.run(emptySubmission, problem);

  expect(fakeAi.calls).toBe(0);
  expect(results).toHaveLength(1);
  expect(results[0].criterionId).toBe('structure-completeness');
});

test('runs registered evaluators when the gate passes, and combines results', async () => {
  const fakeAi = makeFakeEvaluator('fake-ai');
  const service = new EvaluationService({ rubric, evaluators: [fakeAi] });
  const goodSubmission = new Submission({
    id: 's2',
    attemptId: 'a1',
    sections: { 'Only Section': 'x'.repeat(60) },
  });

  const results = await service.run(goodSubmission, problem);

  expect(fakeAi.calls).toBe(1);
  const ids = results.map((r) => r.criterionId).sort();
  expect(ids).toEqual(['quality', 'structure-completeness']);
});

test('an evaluator that does not support the submission format is skipped', async () => {
  const unsupported = makeFakeEvaluator('unsupported', { supports: false });
  const service = new EvaluationService({ rubric, evaluators: [unsupported] });
  const goodSubmission = new Submission({
    id: 's3',
    attemptId: 'a1',
    sections: { 'Only Section': 'x'.repeat(60) },
  });

  const results = await service.run(goodSubmission, problem);

  expect(unsupported.calls).toBe(0);
  expect(results.map((r) => r.criterionId)).toEqual(['structure-completeness']);
});

test('register() rejects an object missing required evaluator members', () => {
  const service = new EvaluationService({ rubric });
  expect(() => service.register({ name: 'broken' })).toThrow(/missing/i);
});
