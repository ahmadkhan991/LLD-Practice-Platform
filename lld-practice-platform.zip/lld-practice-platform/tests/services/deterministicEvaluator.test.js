const DeterministicEvaluator = require('../../src/services/DeterministicEvaluator');
const Problem = require('../../src/domain/Problem');
const Submission = require('../../src/domain/Submission');
const { DEFAULT_RUBRIC } = require('../../src/domain/Rubric');

const problem = new Problem({
  id: 'p1',
  title: 'Test Problem',
  description: 'desc',
  requiredSections: ['Classes & Responsibilities', 'Relationships'],
});
const evaluator = new DeterministicEvaluator();
const criteria = DEFAULT_RUBRIC.deterministicCriteria();

test('scores 1.0 and passes gate when all sections are present and detailed', async () => {
  const submission = new Submission({
    id: 's1',
    attemptId: 'a1',
    sections: {
      'Classes & Responsibilities': 'x'.repeat(60),
      Relationships: 'y'.repeat(60),
    },
  });
  const results = await evaluator.evaluate(submission, problem, criteria);
  expect(results).toHaveLength(1);
  expect(results[0].score).toBe(1);
  expect(DeterministicEvaluator.passesGate(results)).toBe(true);
});

test('flags a missing section and fails the gate', async () => {
  const submission = new Submission({
    id: 's2',
    attemptId: 'a1',
    sections: { 'Classes & Responsibilities': 'x'.repeat(60) },
  });
  const results = await evaluator.evaluate(submission, problem, criteria);
  expect(results[0].score).toBeLessThan(1);
  expect(results[0].concern).toMatch(/Relationships/);
  expect(DeterministicEvaluator.passesGate(results)).toBe(false);
});

test('flags a too-short section distinctly from a missing one', async () => {
  const submission = new Submission({
    id: 's3',
    attemptId: 'a1',
    sections: {
      'Classes & Responsibilities': 'too short',
      Relationships: 'y'.repeat(60),
    },
  });
  const results = await evaluator.evaluate(submission, problem, criteria);
  expect(results[0].concern).toMatch(/short/i);
});
