const EvaluationQueue = require('../../src/services/EvaluationQueue');
const { Evaluation, CriterionResult } = require('../../src/domain/Evaluation');
const { EvaluationStatus } = require('../../src/domain/EvaluationStatus');
const Submission = require('../../src/domain/Submission');
const Problem = require('../../src/domain/Problem');

function makeInMemoryRepos() {
  const evaluations = new Map();
  const submissions = new Map();
  const problems = new Map();
  return {
    evaluationRepository: {
      save: (e) => evaluations.set(e.id, e),
      findById: (id) => evaluations.get(id) || null,
    },
    submissionRepository: {
      save: (s) => submissions.set(s.id, s),
      findById: (id) => submissions.get(id) || null,
    },
    problemRepository: {
      save: (p) => problems.set(p.id, p),
      findById: (id) => problems.get(id) || null,
    },
  };
}

function flushMicroAndMacroTasks() {
  return new Promise((resolve) => setImmediate(resolve));
}

test('processes SUBMITTED -> COMPLETED via the injected evaluation service', async () => {
  const { evaluationRepository, submissionRepository, problemRepository } = makeInMemoryRepos();
  const problem = new Problem({ id: 'p1', title: 'T', description: 'd' });
  const submission = new Submission({ id: 'sub1', attemptId: 'a1', sections: { x: 'y' } });
  problemRepository.save(problem);
  submissionRepository.save(submission);

  const evaluation = new Evaluation({ id: 'e1', submissionId: 'sub1', attemptId: 'a1', problemId: 'p1' });
  evaluationRepository.save(evaluation);

  const evaluationService = {
    run: jest.fn().mockResolvedValue([new CriterionResult({ criterionId: 'c1', score: 1, evaluatorType: 'ai' })]),
  };

  const queue = new EvaluationQueue({ evaluationRepository, evaluationService, problemRepository, submissionRepository });
  queue.enqueue('e1');
  await flushMicroAndMacroTasks();
  await flushMicroAndMacroTasks(); // evaluate() is async internally

  const result = evaluationRepository.findById('e1');
  expect(result.status).toBe(EvaluationStatus.COMPLETED);
  expect(evaluationService.run).toHaveBeenCalledTimes(1);
});

test('marks FAILED without crashing when the evaluation service throws', async () => {
  const { evaluationRepository, submissionRepository, problemRepository } = makeInMemoryRepos();
  const problem = new Problem({ id: 'p1', title: 'T', description: 'd' });
  const submission = new Submission({ id: 'sub1', attemptId: 'a1', sections: { x: 'y' } });
  problemRepository.save(problem);
  submissionRepository.save(submission);
  evaluationRepository.save(new Evaluation({ id: 'e1', submissionId: 'sub1', attemptId: 'a1', problemId: 'p1' }));

  const evaluationService = { run: jest.fn().mockRejectedValue(new Error('boom')) };
  const queue = new EvaluationQueue({ evaluationRepository, evaluationService, problemRepository, submissionRepository });
  queue.enqueue('e1');
  await flushMicroAndMacroTasks();
  await flushMicroAndMacroTasks();

  const result = evaluationRepository.findById('e1');
  expect(result.status).toBe(EvaluationStatus.FAILED);
  expect(result.error).toMatch(/boom/);
});

test('enqueue is idempotent: a second enqueue while in-flight does not run the service twice', async () => {
  const { evaluationRepository, submissionRepository, problemRepository } = makeInMemoryRepos();
  const problem = new Problem({ id: 'p1', title: 'T', description: 'd' });
  const submission = new Submission({ id: 'sub1', attemptId: 'a1', sections: { x: 'y' } });
  problemRepository.save(problem);
  submissionRepository.save(submission);
  evaluationRepository.save(new Evaluation({ id: 'e1', submissionId: 'sub1', attemptId: 'a1', problemId: 'p1' }));

  let resolveRun;
  const evaluationService = {
    run: jest.fn(() => new Promise((resolve) => { resolveRun = resolve; })),
  };
  const queue = new EvaluationQueue({ evaluationRepository, evaluationService, problemRepository, submissionRepository });

  queue.enqueue('e1');
  await flushMicroAndMacroTasks();
  queue.enqueue('e1'); // simulate a retried request while still processing
  resolveRun([]);
  await flushMicroAndMacroTasks();
  await flushMicroAndMacroTasks();

  expect(evaluationService.run).toHaveBeenCalledTimes(1);
});
