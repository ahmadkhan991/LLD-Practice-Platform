const AiEvaluator = require('../../src/services/AiEvaluator');
const Problem = require('../../src/domain/Problem');
const Submission = require('../../src/domain/Submission');
const { DEFAULT_RUBRIC } = require('../../src/domain/Rubric');

const problem = new Problem({ id: 'p1', title: 'Test', description: 'desc' });
const submission = new Submission({
  id: 's1',
  attemptId: 'a1',
  sections: { 'Classes & Responsibilities': 'A Spot class with interface Chargeable, extends nothing.' },
});
const aiCriteria = DEFAULT_RUBRIC.aiCriteria();

test('falls back to mock evaluator when no API key is configured', async () => {
  const evaluator = new AiEvaluator({ apiKey: undefined });
  const results = await evaluator.evaluate(submission, problem, aiCriteria);
  expect(results.length).toBe(aiCriteria.length);
  results.forEach((r) => expect(r.confidence).toBeLessThanOrEqual(0.5)); // mock marks itself low-confidence
});

test('falls back to mock evaluator when the API call throws', async () => {
  const failingFetch = jest.fn().mockRejectedValue(new Error('network down'));
  const evaluator = new AiEvaluator({ apiKey: 'test-key', fetchImpl: failingFetch });
  const results = await evaluator.evaluate(submission, problem, aiCriteria);
  expect(failingFetch).toHaveBeenCalled();
  expect(results.length).toBe(aiCriteria.length);
});

test('parses a well-formed model response into CriterionResults', async () => {
  const modelJson = aiCriteria.map((c) => ({
    criterionId: c.id,
    score: 0.8,
    evidence: 'evidence text',
    concern: '',
    suggestion: 'suggestion text',
    confidence: 0.9,
  }));
  const fakeFetch = jest.fn().mockResolvedValue({
    ok: true,
    json: async () => ({ content: [{ type: 'text', text: JSON.stringify(modelJson) }] }),
  });
  const evaluator = new AiEvaluator({ apiKey: 'test-key', fetchImpl: fakeFetch });
  const results = await evaluator.evaluate(submission, problem, aiCriteria);
  expect(results).toHaveLength(aiCriteria.length);
  expect(results[0].score).toBe(0.8);
  expect(results[0].confidence).toBe(0.9);
});
