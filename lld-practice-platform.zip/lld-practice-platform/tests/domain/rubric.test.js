const { DEFAULT_RUBRIC } = require('../../src/domain/Rubric');

describe('DEFAULT_RUBRIC', () => {
  test('criterion weights sum to 1', () => {
    const total = DEFAULT_RUBRIC.criteria.reduce((sum, c) => sum + c.weight, 0);
    expect(total).toBeCloseTo(1, 5);
  });

  test('splits criteria into deterministic and ai buckets with no overlap', () => {
    const deterministic = DEFAULT_RUBRIC.deterministicCriteria().map((c) => c.id);
    const ai = DEFAULT_RUBRIC.aiCriteria().map((c) => c.id);
    const overlap = deterministic.filter((id) => ai.includes(id));
    expect(overlap).toHaveLength(0);
    expect(deterministic.length + ai.length).toBe(DEFAULT_RUBRIC.criteria.length);
  });
});
