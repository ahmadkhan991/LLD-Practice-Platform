const { Evaluation, CriterionResult } = require('../../src/domain/Evaluation');
const { EvaluationStatus } = require('../../src/domain/EvaluationStatus');
const { Rubric, Criterion } = require('../../src/domain/Rubric');

const rubric = new Rubric({
  id: 'r1',
  criteria: [
    new Criterion({ id: 'a', name: 'A', weight: 0.6, evaluatorType: 'ai' }),
    new Criterion({ id: 'b', name: 'B', weight: 0.4, evaluatorType: 'ai' }),
  ],
});

test('starts SUBMITTED with no results', () => {
  const evaluation = new Evaluation({ id: 'e1', submissionId: 's1' });
  expect(evaluation.status).toBe(EvaluationStatus.SUBMITTED);
  expect(evaluation.overallScore(rubric)).toBeNull();
});

test('markEvaluating then complete computes a weighted overall score', () => {
  const evaluation = new Evaluation({ id: 'e1', submissionId: 's1' });
  evaluation.markEvaluating();
  expect(evaluation.status).toBe(EvaluationStatus.EVALUATING);

  evaluation.complete([
    new CriterionResult({ criterionId: 'a', score: 1, evaluatorType: 'ai' }),
    new CriterionResult({ criterionId: 'b', score: 0, evaluatorType: 'ai' }),
  ]);

  expect(evaluation.status).toBe(EvaluationStatus.COMPLETED);
  expect(evaluation.completedAt).not.toBeNull();
  // weighted: 1*0.6 + 0*0.4 = 0.6
  expect(evaluation.overallScore(rubric)).toBeCloseTo(0.6, 5);
});

test('fail() records the error and marks FAILED', () => {
  const evaluation = new Evaluation({ id: 'e1', submissionId: 's1' });
  evaluation.fail(new Error('evaluator timed out'));
  expect(evaluation.status).toBe(EvaluationStatus.FAILED);
  expect(evaluation.error).toMatch(/timed out/);
});
