const request = require('supertest');
const fs = require('fs');
const path = require('path');
const createApp = require('../../src/app');
const { CriterionResult } = require('../../src/domain/Evaluation');

const TEST_DATA_FILE = path.join(__dirname, '.test-practice-loop.json');

function fakeAiEvaluator() {
  return {
    name: 'fake-ai',
    supports: () => true,
    async evaluate(submission, problem, criteria) {
      return criteria.map(
        (c) => new CriterionResult({ criterionId: c.id, criterionName: c.name, score: 0.75, evaluatorType: 'ai' }),
      );
    },
  };
}

async function waitForTerminalStatus(app, evaluationId, maxAttempts = 20) {
  for (let i = 0; i < maxAttempts; i += 1) {
    const res = await request(app).get(`/api/evaluations/${evaluationId}`);
    if (res.body.status === 'COMPLETED' || res.body.status === 'FAILED') return res.body;
    await new Promise((r) => setTimeout(r, 10));
  }
  throw new Error('Evaluation did not reach a terminal status in time');
}

beforeEach(() => {
  if (fs.existsSync(TEST_DATA_FILE)) fs.unlinkSync(TEST_DATA_FILE);
});
afterAll(() => {
  if (fs.existsSync(TEST_DATA_FILE)) fs.unlinkSync(TEST_DATA_FILE);
});

test('GET /api/problems returns the seeded problems', async () => {
  const { app } = createApp({ dataFile: TEST_DATA_FILE, aiEvaluator: fakeAiEvaluator() });
  const res = await request(app).get('/api/problems');
  expect(res.status).toBe(200);
  expect(res.body.length).toBeGreaterThanOrEqual(4);
  expect(res.body.map((p) => p.id)).toContain('parking-lot');
});

test('full loop: start attempt -> submit -> poll -> completed with feedback', async () => {
  const { app } = createApp({ dataFile: TEST_DATA_FILE, aiEvaluator: fakeAiEvaluator() });

  const start = await request(app).post('/api/attempts').send({ problemId: 'parking-lot' });
  expect(start.status).toBe(201);
  const attemptId = start.body.attempt.id;

  const submit = await request(app)
    .post(`/api/attempts/${attemptId}/submissions`)
    .send({
      sections: {
        'Classes & Responsibilities': 'ParkingLot owns Levels; Level owns Spots; Vehicle is abstract with subclasses.',
        Relationships: 'ParkingLot has-many Level has-many Spot. Vehicle assigned to Spot on entry.',
        Extensibility: 'New vehicle types extend Vehicle without changing ParkingLot.',
        'Edge Cases & Trade-offs': 'Full lot rejects entry. Bus needs contiguous spots, handled by SpotAllocator.',
      },
    });
  expect(submit.status).toBe(202);
  expect(submit.body.evaluation.status).toBe('SUBMITTED');

  const finalEvaluation = await waitForTerminalStatus(app, submit.body.evaluation.id);
  expect(finalEvaluation.status).toBe('COMPLETED');
  expect(finalEvaluation.overallScore).toBeGreaterThan(0);
  expect(finalEvaluation.results.length).toBeGreaterThan(1);

  // History should now show this attempt with its evaluation attached.
  const history = await request(app).get('/api/attempts');
  const entry = history.body.find((h) => h.attempt.id === attemptId);
  expect(entry.evaluation.status).toBe('COMPLETED');
  expect(entry.problemTitle).toBe('Parking Lot');
});

test('an incomplete submission fails the deterministic gate and never reaches the AI evaluator', async () => {
  const evaluator = fakeAiEvaluator();
  evaluator.evaluate = jest.fn(evaluator.evaluate);
  const { app } = createApp({ dataFile: TEST_DATA_FILE, aiEvaluator: evaluator });

  const start = await request(app).post('/api/attempts').send({ problemId: 'vending-machine' });
  const attemptId = start.body.attempt.id;

  const submit = await request(app)
    .post(`/api/attempts/${attemptId}/submissions`)
    .send({ sections: { 'Classes & Responsibilities': 'too short' } });

  const finalEvaluation = await waitForTerminalStatus(app, submit.body.evaluation.id);
  expect(finalEvaluation.status).toBe('COMPLETED'); // gate failing still yields a completed evaluation, just a low one
  expect(finalEvaluation.results).toHaveLength(1);
  expect(finalEvaluation.results[0].criterionId).toBe('structure-completeness');
  expect(evaluator.evaluate).not.toHaveBeenCalled();
});

test('submitting to a non-existent attempt returns 404', async () => {
  const { app } = createApp({ dataFile: TEST_DATA_FILE, aiEvaluator: fakeAiEvaluator() });
  const res = await request(app).post('/api/attempts/does-not-exist/submissions').send({ sections: { a: 'b' } });
  expect(res.status).toBe(404);
});
