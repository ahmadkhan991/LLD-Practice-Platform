# Design Note

## User flow

```
Choose problem  →  Fill structured design  →  Submit  →  Poll status  →  Read rubric feedback  →  Retry (new attempt) or view History
```

Concretely: `GET /api/problems` → learner picks one → `POST /api/attempts` (creates an Attempt) →
learner fills in required sections → `POST /api/attempts/:id/submissions` (creates a Submission,
returns immediately with an Evaluation in `SUBMITTED` status) → frontend polls
`GET /api/evaluations/:id` until `COMPLETED`/`FAILED` → `GET /api/attempts` shows history across
all past attempts.

## Submission format, and why

The learner writes structured **text**, in four fixed sections: *Classes & Responsibilities*,
*Relationships*, *Extensibility*, *Edge Cases & Trade-offs*. This was chosen over a diagram editor
or a code sandbox because:

- It's the smallest format that still gives *evidence* of real design thinking (a name for every
  class isn't enough; the learner has to state a responsibility, which is the actual skill LLD is
  testing).
- It needs zero custom editor UI, keeping build time on domain logic and evaluation, not a canvas.
- Requiring named sections turns "is the submission complete" into an objective, deterministic
  check — see below — rather than something only an LLM can judge.

The trade-off: it can't capture actual code correctness or a precise UML relationship (composition
vs aggregation) the way a diagram or code submission could. That's an explicit scope cut for the
2-day MVP, not an oversight — see "Accommodating other formats" below for how it's absorbed later.

## Domain model

`Problem` (seeded, includes `requiredSections`) → `Attempt` (one learner's try at one Problem) →
`Submission` (what they handed in; content is opaque outside the evaluator layer) → `Evaluation`
(status + per-criterion `CriterionResult[]` + weighted overall score) against a shared `Rubric` of
`Criterion`s, each tagged `deterministic` or `ai`.

Each class owns exactly one responsibility: `Attempt` only tracks which problem/learner; it knows
nothing about submission content or scoring. `Evaluation` owns the status state machine and the
weighted-score math — nothing else in the codebase computes a score or flips a status, which is
what keeps the queue and routes thin.

## Evaluation approach: what's deterministic vs what needs an LLM

| Deterministic | AI |
|---|---|
| Are all required sections present and non-trivial (length-gated)? | Does the design address the stated requirements? |
| — | Does each class have one clear responsibility (coupling/cohesion)? |
| — | Would the design survive a plausible future change? |
| — | Are edge cases identified? |

The deterministic check runs first, as a **gate**: it's free, instant, and catches "the learner
left a section blank" before spending an AI call on something there's nothing to evaluate. Only if
the submission passes the structural gate does it reach the AI evaluator. This directly reflects
the guide's framing — required structure/fields are deterministic; judgement about design quality
is AI's job — and keeps AI cost proportional to submissions that are actually worth reviewing.

Feedback is returned in a fixed shape per criterion (`score → evidence → concern → suggestion →
confidence`), not a single number, because a bare score can't tell a learner what to change, and a
fixed shape is what makes AI feedback comparable across attempts (which is what makes "am I
improving on extensibility specifically" answerable from history).

The AI evaluator calls the real Claude API when `ANTHROPIC_API_KEY` is set, and transparently falls
back to a deterministic mock evaluator (same interface, keyword/length heuristics) when it isn't or
when the call fails — so the prototype runs and is fully demonstrable with zero external
dependencies, while still being a real integration, not a stub pretending to be one.

## Accommodating another evaluation approach or format later

Every evaluator implements one interface: `supports(submission)` + `evaluate(submission, problem,
criteria)`. `EvaluationService` doesn't know or care which concrete evaluators are registered — it
runs the deterministic gate, then fans out to whichever registered evaluators return
`supports() === true`. Concretely:

- **New evaluator** (a second LLM, a rule-based-v2 checker, human review as an async "evaluator"
  that resolves later): implement the interface, `register()` it. Nothing in `EvaluationQueue`,
  the routes, or existing evaluators changes.
- **New submission format** (e.g. a class diagram as `{nodes, edges}` instead of text sections):
  `Submission.format` changes, a new evaluator declares `supports()` for that format and knows how
  to read `content`. `Problem`, `Attempt`, and `Evaluation` are untouched — they never look inside
  submission content.

This is exercised directly by two unit tests (`evaluationService.test.js`) asserting that an
evaluator which doesn't support a format is skipped, and that a new evaluator can be registered and
runs without touching existing code.

## What happens if evaluation is slow or fails

- The `Evaluation` row is written with status `SUBMITTED` **before** any evaluator runs, so the
  learner's submission is never lost if the process crashes mid-evaluation.
- The HTTP handler returns `202 Accepted` immediately; it does not block on the AI call. The
  frontend polls `GET /api/evaluations/:id` instead.
- `EvaluationQueue.enqueue()` is idempotent per evaluation id — a duplicate enqueue (e.g. from a
  learner double-submitting, or a naive client retry) while the same evaluation is already
  in-flight is a no-op, so evaluation never runs twice for one submission.
- On any evaluator throwing (network error, malformed model output, timeout), the Evaluation is
  marked `FAILED` with a message, never left stuck or crashing the server. The learner (or the API)
  can call `POST /api/evaluations/:id/retry`, which is also idempotent-safe.
- This is intentionally an in-process queue (`setImmediate`, in-memory `Set` for in-flight
  tracking), not a distributed broker — per the assignment's scope boundary. If this needed to
  scale past a single instance, the first component I'd split out is exactly this queue, replacing
  its internals with a real broker (e.g. BullMQ/SQS) behind the same `enqueue()` method — routes
  and `EvaluationService` wouldn't change.

## Key trade-offs

- **No auth / single learner.** Deliberate scope cut — an account system doesn't teach anything
  about LLD and would have eaten a third of the two days. `Attempt.learnerId` exists as a field
  specifically so adding real learners later is "populate this field from a session," not a schema
  change.
- **Text over diagram/code.** Discussed above — cheaper to build and evaluate, at the cost of not
  capturing precise structural notation. Acceptable for an MVP; the interface is ready for a
  diagram format to be added alongside it.
- **JSON-file storage over MongoDB.** No DB setup/connection failure surface for a 2-day prototype,
  at the cost of not being production-durable (single file, no concurrent-write safety beyond
  Node's single-threaded event loop). The repository classes mirror what a Mongoose-backed
  repository would expose, so this is a contained swap, not a rewrite, if this became a real
  product on the same stack as other projects (MongoDB Atlas).
- **One shared rubric across all problems**, rather than a rubric per problem. Simpler, and the
  dimensions of "good LLD" (responsibility, coupling, extensibility, edge cases) don't really
  change by problem — problem-specific context is passed into the AI prompt instead of forking the
  rubric per problem.
