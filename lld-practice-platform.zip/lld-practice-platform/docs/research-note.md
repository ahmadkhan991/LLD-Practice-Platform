# Research Note

## The learner problem

Practicing Low-Level Design is easy to *start* and hard to *evaluate*. A learner can sketch a
Parking Lot or Elevator design in twenty minutes and still have no idea whether their class split
is good, whether they've over-engineered it, or whether their design would survive a requirement
change. Unlike DSA practice (where a test suite gives an unambiguous pass/fail), LLD has no single
correct answer — two very different class structures can both be "good," which is exactly what
makes self-assessment hard and what most existing tools skip over.

## What currently exists

- **Interview-prep platforms** (LeetCode-style, and dedicated system-design-interview sites)
  mostly treat LLD as a discussion prompt or a video walkthrough. They give you the problem and a
  reference solution or reference video, but not feedback on *your* solution — you compare
  yourself to a model answer, which teaches pattern-matching more than judgement.
- **GitHub "LLD problems" repositories** (there are many: parking lot, splitwise, elevator,
  tic-tac-toe collections) are excellent as example solutions and requirement lists, but are
  static — no submission flow, no feedback, no retry loop. They're a library, not a practice tool.
- **General-purpose AI chat** (asking ChatGPT/Claude "review my design") gets closer to useful
  feedback, but the feedback is unstructured, inconsistent between runs, and there's no history —
  every session starts from zero, so a learner can't see whether they're actually improving on
  their weak spots over time.
- **Course platforms with LLD modules** (bootcamp-style) usually pair a problem with a rubric a
  human TA applies manually, which doesn't scale and isn't available on demand.

## Key gaps

1. No existing free-standing tool combines *repeatable submission* + *structured, explainable
   feedback* + *attempt history* in one loop. Each piece exists somewhere; the loop doesn't.
2. Feedback that exists is either binary (pass/fail against a reference) or free-text (an AI
   opinion with no fixed dimensions), neither of which tells a learner *which specific thing* to
   fix next time.
3. Nothing captures whether the same weakness (e.g. "always forgets edge cases") recurs across
   attempts, which is the actual signal a learner needs to improve, more than a one-off score.

## Product direction

Build a narrow, repeatable practice loop rather than an LMS: a small set of well-scoped LLD
problems, one deliberately simple submission format (structured text, not a diagram editor or code
sandbox — see design note for why), a fixed multi-dimensional rubric applied consistently by a
combination of deterministic checks and an LLM, and a visible history so a learner can retry and
see whether specific dimensions (e.g. extensibility, edge cases) improve across attempts on
different problems. The bar for "useful" is: after one attempt, the learner knows *exactly* what
to do differently next time, in a form that doesn't disappear when the chat session ends.
